create view role_table_grants as
  SELECT table_privileges.grantor,
         table_privileges.grantee,
         table_privileges.table_catalog,
         table_privileges.table_schema,
         table_privileges.table_name,
         table_privileges.privilege_type,
         table_privileges.is_grantable,
         table_privileges.with_hierarchy
  FROM information_schema.table_privileges
  WHERE (((table_privileges.grantor) :: text IN
          (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)) OR
         ((table_privileges.grantee) :: text IN
          (SELECT enabled_roles.role_name FROM information_schema.enabled_roles)));

alter table role_table_grants
  owner to postgres;

